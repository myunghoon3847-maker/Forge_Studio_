Forge Studio v0.5
- 조립형 로우폴리 템플릿 12종
- Ctrl+Z 실행 취소
- Ctrl+Shift+Z / Ctrl+Y 다시 실행
- Ctrl+D 복제
- Ctrl+S 저장
- Delete / Backspace 삭제

Chrome 또는 Edge에서 index.html을 여세요. Three.js CDN 사용을 위해 인터넷 연결이 필요합니다.
